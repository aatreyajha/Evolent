﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using EvolentApi.Common;
using EvolentApi.Model;
using EvolentApi.Repository;
using Microsoft.AspNetCore.Mvc;

namespace EvolentApi.Controllers
{
    [Route("api/[controller]/[Action]")]
    [ApiController]
    [ServiceFilter(typeof(CustomExceptionFilter))]

    public class HomeController : ControllerBase
    {
        private readonly IUserRepository _userRepository;
        public HomeController(IUserRepository userRepository)
        {
            this._userRepository = userRepository;
        }

        [HttpGet]
        public ActionResult<List<User>> Get()
        {

            List<User> lstUser = _userRepository.GetUser();
            return lstUser;
        }
        [HttpGet]
        public ActionResult<User> GetUserByID([FromQuery]int UserId)
        {
            if (UserId <= 0)
                return NotFound("False UserID");
            User user = _userRepository.GetUserbyId(UserId);
            return user;
        }
        [HttpPost]

        public IActionResult SaveUser([FromBody] User model)
        {
            if (model == null)
            {
              return  NotFound("Evolent user Not Found");
            }

            var data = _userRepository.SaveUser(model);
            string ResposeMsg = ""
;
            if (data == "200")
            {

                if (model.UserId == 0)
                    ResposeMsg = "User saved successfully";
                else
                    ResposeMsg = "User updated successfully";
            }
            else if (data == "201")
            {

                ResposeMsg = "Email Id already exists";
            }
            else if (data == "202")
            {
                ResposeMsg = "Mobile Number already exists";
            }
            return Ok(ResposeMsg);
        }
        [HttpGet]
        public IActionResult DeleteUser([FromQuery]int UserId)
        {
            if (UserId <= 0)
                return NotFound("False UserID");
            string ResponseMessage = "";
            var data = _userRepository.DeleteUser(UserId);
            if (data == "200")
            {
                ResponseMessage = "User Deleted";
            }
            else if (data == "203")
            {
                ResponseMessage = "Invalid record";
            }
            return Ok(ResponseMessage);

        }
    }
}
