﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace EvolentApi.SqlUtility
{
    public static class SqlHelper
    {
        public static string ExecuteProcStringCode(string conString, string procName,
           params SqlParameter[] paramters)
        {
            string result = "";
            using (var sqlConnection = new SqlConnection(conString))
            {
                using (var command = sqlConnection.CreateCommand())
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.CommandText = procName;
                    if (paramters != null)
                    {
                        command.Parameters.AddRange(paramters);
                    }
                    sqlConnection.Open();
                    var ret = command.ExecuteScalar();
                    if (ret != null)
                        result = Convert.ToString(ret);
                }
            }
            return result;
        }

        public static DataTable ExecProcedure(string conString ,string strProName, SqlParameter[] para=null)
        {
            SqlDataAdapter da = null;
            SqlCommand sqlcmd = null;
            try
            {
                using (var sqlConnection = new SqlConnection(conString))
                {
                     sqlcmd = sqlConnection.CreateCommand();
                    sqlcmd.CommandText = strProName;
                    sqlcmd.CommandTimeout = 500;
                    sqlcmd.CommandType = CommandType.StoredProcedure;
                    if (para != null)
                    {
                        foreach (SqlParameter paras in para)
                        {
                            sqlcmd.Parameters.Add(paras);
                        }
                    }
                    DataTable dt = new DataTable();
                    da = new SqlDataAdapter(sqlcmd);
                    da.Fill(dt);
                    return dt;
                }
                  
            }
            finally
            {

                da.Dispose();
                sqlcmd.Dispose();
            }
        }

        ///Methods to get values of 
        ///individual columns from sql data reader
        #region Get Values from Sql Data Reader
        public static string GetNullableString(string Value)
        {
            return Value != string.Empty ? Convert.ToString(Value) : null;
        }

        public static int GetNullableInt32(string Value)
        {
            return Value != string.Empty ? int.Parse(Value) : 0;
        }

       
        #endregion


    }
}
