﻿using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace EvolentApi.Common
{
    public class CustomExceptionFilter : IExceptionFilter
    {
        static string systemPath = Directory.GetCurrentDirectory();
        public void OnException(ExceptionContext context)
        {
            if (!context.ExceptionHandled)
            {

                var exceptionMessage = context.Exception.Message;
                var stackTrace = context.Exception.StackTrace;
                var controllerName = context.RouteData.Values["controller"].ToString();
                var actionName = context.RouteData.Values["action"].ToString();

                string Message = Environment.NewLine + Environment.NewLine+ " Date :" + DateTime.Now.ToString() + ", Controller: " + controllerName + ", Action: " + actionName +
                                 "   Error Message : " + exceptionMessage
                                + Environment.NewLine + "Stack Trace : " + stackTrace;
                File.AppendAllText(systemPath + "/Logs/Log.txt", Message);
                context.ExceptionHandled = true;

            }


        }
    }
}
