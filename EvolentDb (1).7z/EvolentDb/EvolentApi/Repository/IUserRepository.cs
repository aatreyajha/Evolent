﻿using EvolentApi.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EvolentApi.Repository
{
  public  interface IUserRepository
    {
        List<User> GetUser();
        User GetUserbyId(int UserId);
        string SaveUser(User user);
        string DeleteUser(int UserId);
    }
}
