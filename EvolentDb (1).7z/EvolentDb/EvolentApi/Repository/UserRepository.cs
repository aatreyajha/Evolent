﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using EvolentApi.Model;
using EvolentApi.SqlUtility;
using Microsoft.Extensions.Configuration;

namespace EvolentApi.Repository
{
    public class UserRepository : IUserRepository
    {
        private readonly IConfiguration configuration;
        private readonly string _connectionString;
        public UserRepository(IConfiguration config)
        {
            this.configuration = config;
            this._connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        public string DeleteUser(int UserId)
        {
            var outParameter = new SqlParameter("@ReturnCode", SqlDbType.NVarChar, 20)
            {
                Direction = ParameterDirection.Output
            };
            SqlParameter[] param = {
                new SqlParameter("@UserId",UserId),
                outParameter
            };
            SqlHelper.ExecuteProcStringCode(_connectionString, "DeleteUser", param);
            return (string)outParameter.Value;
        }

        public List<User> GetUser()
        {
            List<User> lstUser = new List<User>();
            
            DataTable dtUser = new DataTable();
            dtUser = SqlHelper.ExecProcedure(_connectionString, "[dbo].[sp_GetUser]");
            for (int i = 0; i < dtUser.Rows.Count; i++)
            {
                DataRow dr = dtUser.Rows[i];
                User objUser = new User();

                objUser.UserId = SqlHelper.GetNullableInt32(dr["UserId"].ToString());
                objUser.FirstName = SqlHelper.GetNullableString(dr["FirstName"].ToString());
                objUser.LastName = SqlHelper.GetNullableString(dr["LastName"].ToString());
                objUser.Email = SqlHelper.GetNullableString(dr["Email"].ToString());
                objUser.PhoneNumber = SqlHelper.GetNullableInt32(dr["PhoneNumber"].ToString());
                objUser.Status = SqlHelper.GetNullableString(dr["Status"].ToString());
                lstUser.Add(objUser);
              
            }
            return lstUser;
        }

        public User GetUserbyId(int UserId)
        {

            User objUser = new User();
            DataTable dtUser = new DataTable();
            SqlParameter[] param = {
                new SqlParameter("@UserId",UserId)
                
            };
            dtUser = SqlHelper.ExecProcedure(_connectionString, "[dbo].[sp_GetUserbyID]", param);
            for (int i = 0; i < dtUser.Rows.Count; i++)
            {
                DataRow dr = dtUser.Rows[i];
                objUser.UserId = SqlHelper.GetNullableInt32(dr["UserId"].ToString());
                objUser.FirstName = SqlHelper.GetNullableString(dr["FirstName"].ToString());
                objUser.LastName = SqlHelper.GetNullableString(dr["LastName"].ToString());
                objUser.Email = SqlHelper.GetNullableString(dr["Email"].ToString());
                objUser.PhoneNumber = SqlHelper.GetNullableInt32(dr["PhoneNumber"].ToString());
                objUser.Status = SqlHelper.GetNullableString(dr["Status"].ToString());             
            }
            return objUser;
        }

        public string SaveUser(User user)
        {
            var outParameter = new SqlParameter("@ReturnCode", SqlDbType.NVarChar, 20)
            {
                Direction = ParameterDirection.Output
            };
            SqlParameter[] param = {
                new SqlParameter("@UserId",user.UserId),
                new SqlParameter("@FirstName",user.FirstName),
                 new SqlParameter("@LastName",user.LastName),
                new SqlParameter("@Email",user.Email.ToString()),
                new SqlParameter("@PhoneNumber",user.PhoneNumber),
                new SqlParameter("@Status",user.Status),
                outParameter
            };
            SqlHelper.ExecuteProcStringCode(_connectionString, "SaveUser", param);
            return (string)outParameter.Value;
        }
    }
}
