﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace EvolentUser.Models
{
    public class User
    {
        public int UserId { get; set; }
        [Display(Name = "First Name:")]
        [Required(ErrorMessage = "First Name is Required")]
        [StringLength(30)]
        public string FirstName { get; set; }
        [Display(Name = "Last Name:")]
        [Required(ErrorMessage = "Last Name is Required")]
        [StringLength(30)]
        public string LastName { get; set; }
        [Display(Name = "Email:")]

        public string Email { get; set; }
        [Display(Name = "Phone Number:")]
        [Required(ErrorMessage = "Phone Number is required.")]
     
        public int PhoneNumber { get; set; }
        public string Status { get; set; }



       
    }
}
