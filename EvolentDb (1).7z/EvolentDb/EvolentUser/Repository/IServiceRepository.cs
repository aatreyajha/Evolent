﻿using EvolentUser.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace EvolentUser.Repository
{
 public   interface IServiceRepository
    {
        Task<HttpResponseMessage> GetClient(string url);
        Task<HttpResponseMessage> PostClient(string url,User user);
        Task<HttpResponseMessage> GetDetailsClient(string url, int UserId);
        Task<HttpResponseMessage> DeleteClient(string url, int UserId);
    }
}
