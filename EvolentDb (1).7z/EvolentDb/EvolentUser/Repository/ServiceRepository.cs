﻿using EvolentUser.Models;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Protocols;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace EvolentUser.Repository
{
    public class ServiceRepository : IServiceRepository
    {
        private readonly IConfiguration configuration;
        private readonly string _connectionString;
        public ServiceRepository(IConfiguration config)
        {
            this.configuration = config;
            this._connectionString = configuration.GetConnectionString("ServiceUrl");
           }

        public async Task<HttpResponseMessage> DeleteClient(string url, int UserId)
        {
            using (var Client = new HttpClient())
            {

                Client.BaseAddress = new Uri(_connectionString);
                Client.Timeout = TimeSpan.FromMinutes(10);
                Client.DefaultRequestHeaders.Clear();
                Client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = await Client.GetAsync(url+ UserId);
                return response;
            }
        }

        public async Task<HttpResponseMessage> GetClient(string url)
        {
            using (var Client = new HttpClient())
            {
                
                Client.BaseAddress = new Uri(_connectionString);
                Client.Timeout = TimeSpan.FromMinutes(10);
                Client.DefaultRequestHeaders.Clear();
                Client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = await Client.GetAsync("get/");
                return response;
            }
            
        }

        public async Task<HttpResponseMessage> GetDetailsClient(string url, int UserId)
        {
            using (var Client = new HttpClient())
            {

                Client.BaseAddress = new Uri(_connectionString);
                Client.Timeout = TimeSpan.FromMinutes(10);
                Client.DefaultRequestHeaders.Clear();
                Client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = await Client.GetAsync(url+UserId);
                return response;
            }
        }

        public async Task<HttpResponseMessage> PostClient(string url,User user)
        {
            using (var Client = new HttpClient())
            {

                Client.BaseAddress = new Uri(_connectionString);
                Client.Timeout = TimeSpan.FromMinutes(10);
                Client.DefaultRequestHeaders.Clear();
                Client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                HttpResponseMessage response = await Client.PostAsJsonAsync(url,user);
                return response;
            }

        }
    }
}
