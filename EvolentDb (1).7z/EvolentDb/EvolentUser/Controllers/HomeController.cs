﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using EvolentUser.Models;
using EvolentUser.Repository;
using System.Net.Http;
using Newtonsoft.Json;
using System.Net.Http.Headers;
using EvolentUser.Common;

namespace EvolentUser.Controllers
{
    [ServiceFilter(typeof(CustomExceptionFilter))]
    public class HomeController : Controller
    {
        private readonly IServiceRepository _serviceRepository;
        public HomeController(IServiceRepository serviceRepository)
        {
            this._serviceRepository = serviceRepository;
        }
        public async Task<IActionResult> GetUser()
        {
            
            List<User> lstUser = new List<User>();
            HttpResponseMessage response = await _serviceRepository.GetClient("Get");
            if (response.IsSuccessStatusCode)
            {
                var clientResponse = response.Content.ReadAsStringAsync().Result;
                lstUser = JsonConvert.DeserializeObject<List<User>>(clientResponse);
            }

            return View(lstUser);
        }
        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public async Task<ActionResult> Create([Bind("FirstName,LastName,Email,PhoneNumber,Status")] User user)
        {
            if (ModelState.IsValid)

            {
                HttpResponseMessage response = await _serviceRepository.PostClient("SaveUser",user);
                if (response.IsSuccessStatusCode)
                {
                    return RedirectToAction("GetUser");
                }
                else
                {
                    ModelState.AddModelError(string.Empty, "Server error try after some time.");
                }
                
            }
                return View(user);
        }

        [HttpGet]
        public async Task<ActionResult> Edit([FromQuery]int UserId)
        {
            User user = new User();
            HttpResponseMessage response = await _serviceRepository.GetDetailsClient("GetUserByID/?UserId=", UserId);
            if (response.IsSuccessStatusCode)
            {
                var clientResponse = response.Content.ReadAsStringAsync().Result;
                user = JsonConvert.DeserializeObject<User>(clientResponse);
            }


            return View(user);
        }
        [HttpPost]
        public async Task<ActionResult> Edit([Bind("UserId,FirstName,LastName,Email,PhoneNumber,Status")] User user)
        {
            if (ModelState.IsValid)

            {
                HttpResponseMessage response = await _serviceRepository.PostClient("SaveUser", user);
                if (response.IsSuccessStatusCode)
                {
                    return RedirectToAction("GetUser");
                }
                else
                {
                    ModelState.AddModelError(string.Empty, "Server error try after some time.");
                }

            }
            return View(user);
        }


        public async Task<ActionResult> Details([FromQuery]int UserId)
        {
            User user = new User();
            HttpResponseMessage response = await _serviceRepository.GetDetailsClient("GetUserByID/?UserId=", UserId);
            if (response.IsSuccessStatusCode)
            {
                var clientResponse = response.Content.ReadAsStringAsync().Result;
                user = JsonConvert.DeserializeObject<User>(clientResponse);
            }


            return View(user);
        }

        public async Task<ActionResult> Delete([FromQuery]int UserId)
        {
            if (ModelState.IsValid)

            {
                HttpResponseMessage response = await _serviceRepository.DeleteClient("DeleteUser/?UserId=", UserId);
                if (response.IsSuccessStatusCode)
                {
                    return RedirectToAction("GetUser");
                }
                else
                {
                    ModelState.AddModelError(string.Empty, "Server error try after some time.");
                }

            }
            return RedirectToAction("getuser");
        }
    }
}
