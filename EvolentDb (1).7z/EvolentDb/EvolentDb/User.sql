﻿CREATE TABLE [dbo].[User]
(
	[UserId] INT NOT NULL PRIMARY KEY IDENTITY(1,1),
	[FirstName] nvarchar (100) not null,
	[LastName] nvarchar (100) not null,
	[Email] nvarchar (100) not null,
	[PhoneNumber] int not null,
	[Status] nvarchar(100) not null
)
