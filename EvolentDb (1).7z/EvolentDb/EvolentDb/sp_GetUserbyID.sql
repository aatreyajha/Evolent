﻿CREATE PROCEDURE [dbo].[sp_GetUserbyID]
		@UserId INT
AS
	BEGIN  
        select *  FROM [dbo].[User] WHERE  UserId = @UserId
        
END