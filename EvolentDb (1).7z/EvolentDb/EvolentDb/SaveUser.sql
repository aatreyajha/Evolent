﻿CREATE PROCEDURE [dbo].[SaveUser]
	@UserId INT,  
@FirstName NVARCHAR(MAX),  
@LastName NVARCHAR(MAX),  
@Email NVARCHAR(max),  
@PhoneNumber int, 
@Status NVARCHAR(MAX),
@ReturnCode NVARCHAR(20) OUTPUT  
AS
	BEGIN  
    SET @ReturnCode = '200'  
    IF(@UserId <> 0)  
    BEGIN  
        UPDATE [dbo].[User] SET  
        FirstName = @FirstName,  
        LastName = @LastName,  
        Email = @Email,  
        PhoneNumber = @PhoneNumber,  
        Status =  @Status
        WHERE UserId = @UserId  
  
        SET @ReturnCode = '200'  
    END  
    ELSE  
    BEGIN  
        INSERT INTO [dbo].[User] (FirstName,LastName,Email,PhoneNumber,Status)  
        VALUES (@FirstName,@LastName,@Email,@PhoneNumber,@Status)  
  
        SET @ReturnCode = '200'  
    END  
END  