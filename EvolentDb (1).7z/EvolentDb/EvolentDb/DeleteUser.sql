﻿CREATE PROCEDURE [dbo].[DeleteUser]
	@UserId INT,  
@ReturnCode NVARCHAR(20) OUTPUT  
AS
	BEGIN  

    SET @ReturnCode = '200'  
    IF NOT EXISTS (SELECT 1 FROM [dbo].[User] WHERE UserId = @UserId)  
    BEGIN  
        SET @ReturnCode ='203'  
        RETURN  
    END  
    ELSE  
    BEGIN  
        DELETE FROM [dbo].[User] WHERE  UserId = @UserId
        SET @ReturnCode = '200'  
        RETURN  
    END  
END