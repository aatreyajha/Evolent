﻿CREATE PROCEDURE [dbo].[sp_GetUser]
AS
	SELECT * from [dbo].[User] 
Go;
